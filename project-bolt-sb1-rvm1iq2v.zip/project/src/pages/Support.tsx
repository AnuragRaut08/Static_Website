import React from 'react';
import { MessageSquare, Phone, Mail, FileQuestion } from 'lucide-react';

function Support() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold text-gray-900">How can we help you?</h1>
        <p className="mt-4 text-lg text-gray-500">
          Our team is here to assist you with any questions or concerns
        </p>
      </div>

      <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4 mb-12">
        <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-100 text-blue-600 mb-4 mx-auto">
            <MessageSquare className="h-6 w-6" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 text-center mb-2">Live Chat</h3>
          <p className="text-sm text-gray-500 text-center">
            Chat with our support team in real-time
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-100 text-blue-600 mb-4 mx-auto">
            <Phone className="h-6 w-6" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 text-center mb-2">Phone Support</h3>
          <p className="text-sm text-gray-500 text-center">
            Call us at 1-800-REALOGIX
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-100 text-blue-600 mb-4 mx-auto">
            <Mail className="h-6 w-6" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 text-center mb-2">Email Support</h3>
          <p className="text-sm text-gray-500 text-center">
            support@realogix.com
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-100 text-blue-600 mb-4 mx-auto">
            <FileQuestion className="h-6 w-6" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 text-center mb-2">Knowledge Base</h3>
          <p className="text-sm text-gray-500 text-center">
            Browse our help articles
          </p>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h2>
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">How do I get started with Realogix?</h3>
            <p className="text-gray-500">
              Getting started is easy! Simply sign up for an account, and our team will guide you through the onboarding process.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">What types of properties do you support?</h3>
            <p className="text-gray-500">
              We support various types of commercial properties, including warehouses, distribution centers, and logistics hubs.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">How does the AI-powered analytics work?</h3>
            <p className="text-gray-500">
              Our AI system analyzes historical data, market trends, and property performance to provide actionable insights and predictions.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Is my data secure?</h3>
            <p className="text-gray-500">
              Yes, we use enterprise-grade security measures and blockchain technology to ensure your data is always protected.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}