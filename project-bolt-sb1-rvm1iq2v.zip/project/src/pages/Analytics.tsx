import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, DollarSign, Building, Users } from 'lucide-react';

const predictiveData = [
  { month: 'Jan', actual: 4000, predicted: 4200 },
  { month: 'Feb', actual: 3000, predicted: 3500 },
  { month: 'Mar', actual: 2000, predicted: 2800 },
  { month: 'Apr', actual: 2780, predicted: 3000 },
  { month: 'May', actual: 1890, predicted: 2200 },
  { month: 'Jun', actual: 2390, predicted: 2600 },
];

function Analytics() {
  const [timeframe, setTimeframe] = useState('monthly');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Predictive Analytics</h1>
        <p className="text-gray-600">Advanced insights and predictions for your real estate portfolio</p>
      </div>

      {/* Analytics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Predicted Growth</p>
              <p className="text-2xl font-bold text-green-600">+15.4%</p>
            </div>
            <TrendingUp className="h-8 w-8 text-green-500" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Expected Revenue</p>
              <p className="text-2xl font-bold text-gray-900">$2.4M</p>
            </div>
            <DollarSign className="h-8 w-8 text-blue-500" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Property Value</p>
              <p className="text-2xl font-bold text-gray-900">$18.2M</p>
            </div>
            <Building className="h-8 w-8 text-purple-500" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Tenant Satisfaction</p>
              <p className="text-2xl font-bold text-blue-600">94%</p>
            </div>
            <Users className="h-8 w-8 text-blue-500" />
          </div>
        </div>
      </div>

      {/* Chart Section */}
      <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-semibold text-gray-900">Performance Prediction</h2>
          <select
            value={timeframe}
            onChange={(e) => setTimeframe(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-md text-sm"
          >
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
            <option value="yearly">Yearly</option>
          </select>
        </div>
        <div className="h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={predictiveData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="actual" fill="#3B82F6" name="Actual Performance" />
              <Bar dataKey="predicted" fill="#93C5FD" name="Predicted Performance" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Insights Section */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">AI-Generated Insights</h2>
        <div className="space-y-4">
          <div className="p-4 bg-blue-50 rounded-lg">
            <h3 className="font-medium text-blue-900">Market Trend Analysis</h3>
            <p className="text-blue-700 mt-1">Property values in your portfolio areas are predicted to increase by 12% over the next quarter.</p>
          </div>
          <div className="p-4 bg-green-50 rounded-lg">
            <h3 className="font-medium text-green-900">Optimization Opportunities</h3>
            <p className="text-green-700 mt-1">Increasing maintenance efficiency could reduce operational costs by 8% annually.</p>
          </div>
          <div className="p-4 bg-purple-50 rounded-lg">
            <h3 className="font-medium text-purple-900">Risk Assessment</h3>
            <p className="text-purple-700 mt-1">Current market conditions suggest low risk for your property portfolio with a 95% confidence level.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Analytics;