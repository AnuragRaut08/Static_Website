import React from 'react';
import { Link } from 'react-router-dom';
import { Building2, BarChart3, Shield, MessageSquare } from 'lucide-react';

function Home() {
  return (
    <div className="bg-gradient-to-b from-blue-50 to-white">
      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16 text-center">
        <h1 className="text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl">
          <span className="block">Smart Logistics</span>
          <span className="block text-blue-600">Real Estate Solutions</span>
        </h1>
        <p className="mt-3 max-w-md mx-auto text-base text-gray-500 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
          Transform your logistics operations with AI-powered insights and IoT monitoring
        </p>
        <div className="mt-5 max-w-md mx-auto sm:flex sm:justify-center md:mt-8">
          <Link
            to="/dashboard"
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700"
          >
            Get Started
          </Link>
          <Link
            to="/properties"
            className="mt-3 sm:mt-0 sm:ml-3 inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200"
          >
            View Properties
          </Link>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          <div className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white mx-auto">
              <Building2 className="h-6 w-6" />
            </div>
            <h3 className="mt-5 text-lg font-medium text-gray-900 text-center">Smart Warehouses</h3>
            <p className="mt-2 text-sm text-gray-500 text-center">
              IoT-enabled monitoring for real-time insights into your facility operations
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white mx-auto">
              <BarChart3 className="h-6 w-6" />
            </div>
            <h3 className="mt-5 text-lg font-medium text-gray-900 text-center">Predictive Analytics</h3>
            <p className="mt-2 text-sm text-gray-500 text-center">
              AI-powered insights for better investment decisions
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white mx-auto">
              <Shield className="h-6 w-6" />
            </div>
            <h3 className="mt-5 text-lg font-medium text-gray-900 text-center">Secure Platform</h3>
            <p className="mt-2 text-sm text-gray-500 text-center">
              Blockchain-backed security for all your transactions
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white mx-auto">
              <MessageSquare className="h-6 w-6" />
            </div>
            <h3 className="mt-5 text-lg font-medium text-gray-900 text-center">Smart Assistant</h3>
            <p className="mt-2 text-sm text-gray-500 text-center">
              24/7 AI-powered chatbot support for instant help and property information
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}