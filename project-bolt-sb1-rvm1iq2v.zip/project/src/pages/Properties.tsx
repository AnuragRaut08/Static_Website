import React from 'react';
import { MapPin, Building2, ArrowUpRight } from 'lucide-react';

const properties = [
  {
    id: 1,
    name: 'Silicon Valley Tech Hub',
    location: 'San Francisco, CA',
    type: 'Warehouse & Distribution',
    size: '125,000 sq ft',
    occupancy: '95%',
    image: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 2,
    name: 'Midwest Logistics Center',
    location: 'Chicago, IL',
    type: 'Logistics Hub',
    size: '250,000 sq ft',
    occupancy: '88%',
    image: 'https://images.unsplash.com/photo-1587293852726-70cdb56c2866?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 3,
    name: 'East Coast Distribution',
    location: 'New York, NY',
    type: 'Distribution Center',
    size: '180,000 sq ft',
    occupancy: '92%',
    image: 'https://images.unsplash.com/photo-1565610222536-ef125c59da2e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
  }
];

function Properties() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Properties</h1>
          <p className="text-gray-500">Manage and monitor your real estate portfolio</p>
        </div>
        <button className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700">
          Add New Property
        </button>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {properties.map((property) => (
          <div key={property.id} className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow">
            <div className="h-48 w-full relative">
              <img
                src={property.image}
                alt={property.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 right-4 bg-white rounded-full p-2 shadow-sm">
                <ArrowUpRight className="h-4 w-4 text-blue-600" />
              </div>
            </div>
            <div className="p-6">
              <div className="flex items-center mb-2">
                <Building2 className="h-5 w-5 text-blue-600 mr-2" />
                <h3 className="text-lg font-medium text-gray-900">{property.name}</h3>
              </div>
              <div className="flex items-center text-gray-500 text-sm mb-4">
                <MapPin className="h-4 w-4 mr-1" />
                {property.location}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Type</p>
                  <p className="font-medium text-gray-900">{property.type}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Size</p>
                  <p className="font-medium text-gray-900">{property.size}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Occupancy</p>
                  <p className="font-medium text-green-600">{property.occupancy}</p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}